package org.techtown.courage;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by jisub on 2017-12-01.
 */

public class userActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_item);


    }
}
