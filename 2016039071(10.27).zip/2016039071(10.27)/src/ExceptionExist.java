
public class ExceptionExist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		func();
	}
	
	static void func()
	{
		int i=1;
		int j=0;
		System.out.println(i/j);
	}

}

