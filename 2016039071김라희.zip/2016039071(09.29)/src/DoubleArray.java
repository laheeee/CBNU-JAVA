
public class DoubleArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][]arr= {{10,20},{30,40}};
		int i,j;
		
		for(i=0;i<arr.length;i++)
		{
			for(j=0;j<arr[i].length;j++)
				System.out.println(" "+arr[i][j]);
			System.out.println();
		}
	}

}
