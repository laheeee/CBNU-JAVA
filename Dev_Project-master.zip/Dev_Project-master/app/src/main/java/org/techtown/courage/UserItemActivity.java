package org.techtown.courage;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by jisub on 2017-11-24.
 */

public class UserItemActivity extends AppCompatActivity{

   /*TextView textView;
    TextView textView2;*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_item);

        /*textView = (TextView) findViewById(R.id.textView);
        textView2 = (TextView) findViewById(R.id.textView2);*/

       /* Button button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Toast.makeText(getApplicationContext(),"전화번호를 삭제하였습니다!",Toast.LENGTH_LONG).show();
            }
        });*/
    }
}
