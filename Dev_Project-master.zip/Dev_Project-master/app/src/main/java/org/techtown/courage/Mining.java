package org.techtown.courage;

/**
 * Created by kop48 on 2017-10-08.
 */

public class Mining {
    int mwriteCat;
    String muserID;

    public Mining(String muserID) {
        this.muserID = muserID;
    }

    public String getMuserID() {
        return muserID;
    }

    public void setMuserID(String muserID) {
        this.muserID = muserID;
    }
}