import static java.lang.System.out;
import static java.lang.Thread.MAX_PRIORITY;
public class StaticImport {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		out.println("Hello");
		out.println(MAX_PRIORITY);

	}

}
